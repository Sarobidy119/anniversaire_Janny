import Hero from "./components/Hero";
import BirthdayMessage from "./components/BirthdayMessage";
import Wishes from "./components/Wishes";
import Gallery from "./components/Gallery";
import Surprise from "./components/Surprise";
import Blessing from "./components/Blessing";
import MusicPlayer from "./components/MusicPlayer";
import FinalSection from "./components/FinalSection";

function App() {
  return (
    <>
      <Hero />
      <BirthdayMessage />
      <Wishes />
      <Gallery />
      <Surprise />
      <Blessing />
      <FinalSection />
      <MusicPlayer />
    </>
  );
}

export default App;
