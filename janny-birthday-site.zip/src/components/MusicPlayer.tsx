import { useRef, useState } from "react";
import { config } from "../config";
import "./MusicPlayer.css";

export default function MusicPlayer() {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);

  const toggle = async () => {
    const audio = audioRef.current;
    if (!audio) return;

    try {
      if (isPlaying) {
        audio.pause();
        setIsPlaying(false);
      } else {
        await audio.play();
        setIsPlaying(true);
        setNotice(null);
      }
    } catch {
      // Se déclenche si src/assets/audio/birthday.mp3 n'a pas encore été ajouté
      setNotice("Ajoute ton fichier birthday.mp3 dans src/assets/audio pour activer la musique 🎵");
      setTimeout(() => setNotice(null), 4000);
    }
  };

  return (
    <div className="music-player">
      {notice && <div className="music-notice">{notice}</div>}
      <button
        className={`music-button ${isPlaying ? "playing" : ""}`}
        onClick={toggle}
        aria-label={isPlaying ? "Mettre la musique en pause" : "Lancer la musique d'anniversaire"}
      >
        {isPlaying ? "⏸" : "▶️"}
        {isPlaying && (
          <>
            <span className="pulse-ring" />
            <span className="pulse-ring delay" />
          </>
        )}
      </button>
      {/* eslint-disable-next-line jsx-a11y/media-has-caption */}
      <audio ref={audioRef} src={config.musicSrc} loop preload="none" />
    </div>
  );
}
