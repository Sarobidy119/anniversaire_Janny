import { motion } from "framer-motion";
import { config } from "../config";
import FloatingField from "./FloatingField";
import "./Blessing.css";

export default function Blessing() {
  return (
    <section className="section blessing-section">
      <FloatingField variant="stars" count={26} colors={["#F2DCAA", "#FFFFFF", "#D8C8F0"]} />
      <div className="section-inner">
        <motion.div
          className="blessing-content"
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.5 }}
          transition={{ duration: 0.9, ease: [0.16, 1, 0.3, 1] }}
        >
          <span className="blessing-glyph">✦</span>
          <p className="blessing-text">{config.blessingMessage}</p>
          <span className="blessing-glyph">✦</span>
        </motion.div>
      </div>
    </section>
  );
}
