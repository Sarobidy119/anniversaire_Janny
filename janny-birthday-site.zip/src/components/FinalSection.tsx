import { useRef } from "react";
import { motion, useInView } from "framer-motion";
import { config } from "../config";
import { burstConfetti } from "../lib/confetti";
import FloatingField from "./FloatingField";
import "./FinalSection.css";

export default function FinalSection() {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, amount: 0.6 });

  if (inView) {
    // léger décalage pour laisser l'entrée se jouer d'abord
    window.setTimeout(burstConfetti, 250);
  }

  return (
    <section className="section final-section" ref={ref}>
      <FloatingField variant="dots" count={16} colors={["#F0A8C0", "#D9A94E", "#FFFFFF"]} />
      <div className="section-inner">
        <motion.div
          className="final-content"
          initial={{ opacity: 0, scale: 0.92 }}
          animate={inView ? { opacity: 1, scale: 1 } : {}}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
        >
          <p className="final-kicker">Encore une fois...</p>
          <h2 className="final-title">
            🎂 Joyeux anniversaire {config.friendName} ! 🎂
          </h2>
          <p className="final-tagline">{config.finalTagline}</p>
          <p className="final-fullname">{config.fullName}</p>
        </motion.div>
      </div>
    </section>
  );
}
